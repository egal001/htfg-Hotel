export class AppSettings {
	public static API_URL = 'https://rrhotels.herokuapp.com/api/v1/'
}