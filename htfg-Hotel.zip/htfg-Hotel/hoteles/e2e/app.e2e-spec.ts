import { AppPage } from './app.po';

describe('tfg App', () => {
  let page: AppPage;

  beforeEach(() => {
    page = new AppPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!');
  });
});
function beforeEach(arg0: () => void) {
  throw new Error('Function not implemented.');
}

