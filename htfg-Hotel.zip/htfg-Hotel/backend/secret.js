module.exports = {
	'CODE': 'changeit'
}
